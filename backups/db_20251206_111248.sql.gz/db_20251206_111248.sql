--
-- PostgreSQL database dump
--

\restrict s04IgkFwENZs3U7rb1smnOaXJ2T5I9rcbQWOnjP0mGAUiAfsUgnvZgQxjHfwtrb

-- Dumped from database version 15.15
-- Dumped by pg_dump version 15.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: docent_user
--

CREATE TABLE public.activity_logs (
    id integer NOT NULL,
    company_id integer,
    user_id integer,
    action character varying(255) NOT NULL,
    details jsonb DEFAULT '{}'::jsonb,
    "timestamp" timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.activity_logs OWNER TO docent_user;

--
-- Name: activity_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: docent_user
--

CREATE SEQUENCE public.activity_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.activity_logs_id_seq OWNER TO docent_user;

--
-- Name: activity_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: docent_user
--

ALTER SEQUENCE public.activity_logs_id_seq OWNED BY public.activity_logs.id;


--
-- Name: case_instances; Type: TABLE; Schema: public; Owner: docent_user
--

CREATE TABLE public.case_instances (
    id integer NOT NULL,
    template_id integer NOT NULL,
    company_id integer NOT NULL,
    data_json jsonb NOT NULL,
    generated_summary text,
    created_by integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.case_instances OWNER TO docent_user;

--
-- Name: case_instances_id_seq; Type: SEQUENCE; Schema: public; Owner: docent_user
--

CREATE SEQUENCE public.case_instances_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.case_instances_id_seq OWNER TO docent_user;

--
-- Name: case_instances_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: docent_user
--

ALTER SEQUENCE public.case_instances_id_seq OWNED BY public.case_instances.id;


--
-- Name: case_templates; Type: TABLE; Schema: public; Owner: docent_user
--

CREATE TABLE public.case_templates (
    id integer NOT NULL,
    company_id integer,
    name character varying(255) NOT NULL,
    template_json jsonb NOT NULL,
    created_by integer,
    is_default boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.case_templates OWNER TO docent_user;

--
-- Name: case_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: docent_user
--

CREATE SEQUENCE public.case_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.case_templates_id_seq OWNER TO docent_user;

--
-- Name: case_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: docent_user
--

ALTER SEQUENCE public.case_templates_id_seq OWNED BY public.case_templates.id;


--
-- Name: companies; Type: TABLE; Schema: public; Owner: docent_user
--

CREATE TABLE public.companies (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    domain_restriction character varying(255),
    plan_limits jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.companies OWNER TO docent_user;

--
-- Name: companies_id_seq; Type: SEQUENCE; Schema: public; Owner: docent_user
--

CREATE SEQUENCE public.companies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.companies_id_seq OWNER TO docent_user;

--
-- Name: companies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: docent_user
--

ALTER SEQUENCE public.companies_id_seq OWNED BY public.companies.id;


--
-- Name: departments; Type: TABLE; Schema: public; Owner: docent_user
--

CREATE TABLE public.departments (
    id integer NOT NULL,
    company_id integer NOT NULL,
    name character varying(255) NOT NULL,
    parent_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.departments OWNER TO docent_user;

--
-- Name: departments_id_seq; Type: SEQUENCE; Schema: public; Owner: docent_user
--

CREATE SEQUENCE public.departments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.departments_id_seq OWNER TO docent_user;

--
-- Name: departments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: docent_user
--

ALTER SEQUENCE public.departments_id_seq OWNED BY public.departments.id;


--
-- Name: doc_chunks; Type: TABLE; Schema: public; Owner: docent_user
--

CREATE TABLE public.doc_chunks (
    id integer NOT NULL,
    document_id integer NOT NULL,
    company_id integer NOT NULL,
    chunk_text text NOT NULL,
    chunk_index integer NOT NULL,
    chunk_id_for_vector character varying(255) NOT NULL,
    chunk_metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.doc_chunks OWNER TO docent_user;

--
-- Name: doc_chunks_id_seq; Type: SEQUENCE; Schema: public; Owner: docent_user
--

CREATE SEQUENCE public.doc_chunks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.doc_chunks_id_seq OWNER TO docent_user;

--
-- Name: doc_chunks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: docent_user
--

ALTER SEQUENCE public.doc_chunks_id_seq OWNED BY public.doc_chunks.id;


--
-- Name: documents; Type: TABLE; Schema: public; Owner: docent_user
--

CREATE TABLE public.documents (
    id integer NOT NULL,
    company_id integer NOT NULL,
    uploaded_by integer NOT NULL,
    filename character varying(500) NOT NULL,
    mime_type character varying(100) NOT NULL,
    storage_path character varying(1000) NOT NULL,
    status character varying(50) DEFAULT 'pending'::character varying,
    doc_metadata jsonb DEFAULT '{}'::jsonb,
    summary text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    processed_at timestamp without time zone
);


ALTER TABLE public.documents OWNER TO docent_user;

--
-- Name: documents_id_seq; Type: SEQUENCE; Schema: public; Owner: docent_user
--

CREATE SEQUENCE public.documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.documents_id_seq OWNER TO docent_user;

--
-- Name: documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: docent_user
--

ALTER SEQUENCE public.documents_id_seq OWNED BY public.documents.id;


--
-- Name: onboarding_paths; Type: TABLE; Schema: public; Owner: docent_user
--

CREATE TABLE public.onboarding_paths (
    id integer NOT NULL,
    company_id integer NOT NULL,
    department_id integer,
    name character varying(255) NOT NULL,
    steps_json jsonb NOT NULL,
    created_by integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.onboarding_paths OWNER TO docent_user;

--
-- Name: onboarding_paths_id_seq; Type: SEQUENCE; Schema: public; Owner: docent_user
--

CREATE SEQUENCE public.onboarding_paths_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.onboarding_paths_id_seq OWNER TO docent_user;

--
-- Name: onboarding_paths_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: docent_user
--

ALTER SEQUENCE public.onboarding_paths_id_seq OWNED BY public.onboarding_paths.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: docent_user
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    company_id integer NOT NULL,
    name character varying(100) NOT NULL,
    permissions jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.roles OWNER TO docent_user;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: docent_user
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_id_seq OWNER TO docent_user;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: docent_user
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: search_history; Type: TABLE; Schema: public; Owner: docent_user
--

CREATE TABLE public.search_history (
    id integer NOT NULL,
    user_id integer NOT NULL,
    company_id integer NOT NULL,
    query_text text NOT NULL,
    results_meta jsonb DEFAULT '{}'::jsonb,
    "timestamp" timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.search_history OWNER TO docent_user;

--
-- Name: search_history_id_seq; Type: SEQUENCE; Schema: public; Owner: docent_user
--

CREATE SEQUENCE public.search_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.search_history_id_seq OWNER TO docent_user;

--
-- Name: search_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: docent_user
--

ALTER SEQUENCE public.search_history_id_seq OWNED BY public.search_history.id;


--
-- Name: system_admins; Type: TABLE; Schema: public; Owner: docent_user
--

CREATE TABLE public.system_admins (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    hashed_password character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.system_admins OWNER TO docent_user;

--
-- Name: system_admins_id_seq; Type: SEQUENCE; Schema: public; Owner: docent_user
--

CREATE SEQUENCE public.system_admins_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.system_admins_id_seq OWNER TO docent_user;

--
-- Name: system_admins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: docent_user
--

ALTER SEQUENCE public.system_admins_id_seq OWNED BY public.system_admins.id;


--
-- Name: user_onboarding_progress; Type: TABLE; Schema: public; Owner: docent_user
--

CREATE TABLE public.user_onboarding_progress (
    id integer NOT NULL,
    user_id integer NOT NULL,
    path_id integer NOT NULL,
    company_id integer NOT NULL,
    current_step integer DEFAULT 0,
    completed_steps jsonb DEFAULT '[]'::jsonb,
    progress_data jsonb DEFAULT '{}'::jsonb,
    started_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    completed_at timestamp without time zone
);


ALTER TABLE public.user_onboarding_progress OWNER TO docent_user;

--
-- Name: user_onboarding_progress_id_seq; Type: SEQUENCE; Schema: public; Owner: docent_user
--

CREATE SEQUENCE public.user_onboarding_progress_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_onboarding_progress_id_seq OWNER TO docent_user;

--
-- Name: user_onboarding_progress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: docent_user
--

ALTER SEQUENCE public.user_onboarding_progress_id_seq OWNED BY public.user_onboarding_progress.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: docent_user
--

CREATE TABLE public.users (
    id integer NOT NULL,
    company_id integer NOT NULL,
    role_id integer,
    email character varying(255) NOT NULL,
    hashed_password character varying(255),
    name character varying(255) NOT NULL,
    is_active boolean DEFAULT true,
    last_login timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    notification_preferences jsonb DEFAULT '{"email_on_new_case": true, "email_weekly_digest": true, "email_onboarding_reminders": true, "email_on_document_processed": true}'::jsonb
);


ALTER TABLE public.users OWNER TO docent_user;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: docent_user
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO docent_user;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: docent_user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: activity_logs id; Type: DEFAULT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.activity_logs ALTER COLUMN id SET DEFAULT nextval('public.activity_logs_id_seq'::regclass);


--
-- Name: case_instances id; Type: DEFAULT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.case_instances ALTER COLUMN id SET DEFAULT nextval('public.case_instances_id_seq'::regclass);


--
-- Name: case_templates id; Type: DEFAULT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.case_templates ALTER COLUMN id SET DEFAULT nextval('public.case_templates_id_seq'::regclass);


--
-- Name: companies id; Type: DEFAULT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.companies ALTER COLUMN id SET DEFAULT nextval('public.companies_id_seq'::regclass);


--
-- Name: departments id; Type: DEFAULT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.departments ALTER COLUMN id SET DEFAULT nextval('public.departments_id_seq'::regclass);


--
-- Name: doc_chunks id; Type: DEFAULT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.doc_chunks ALTER COLUMN id SET DEFAULT nextval('public.doc_chunks_id_seq'::regclass);


--
-- Name: documents id; Type: DEFAULT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.documents ALTER COLUMN id SET DEFAULT nextval('public.documents_id_seq'::regclass);


--
-- Name: onboarding_paths id; Type: DEFAULT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.onboarding_paths ALTER COLUMN id SET DEFAULT nextval('public.onboarding_paths_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: search_history id; Type: DEFAULT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.search_history ALTER COLUMN id SET DEFAULT nextval('public.search_history_id_seq'::regclass);


--
-- Name: system_admins id; Type: DEFAULT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.system_admins ALTER COLUMN id SET DEFAULT nextval('public.system_admins_id_seq'::regclass);


--
-- Name: user_onboarding_progress id; Type: DEFAULT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.user_onboarding_progress ALTER COLUMN id SET DEFAULT nextval('public.user_onboarding_progress_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: docent_user
--

COPY public.activity_logs (id, company_id, user_id, action, details, "timestamp") FROM stdin;
1	1	2	User Login	{"email": "admin@democorp.com"}	2025-12-06 04:01:13.466054
2	1	2	User Login	{"email": "admin@democorp.com"}	2025-12-06 04:02:28.902485
3	1	2	User Login	{"email": "admin@democorp.com"}	2025-12-06 04:02:46.622158
4	1	2	User Login	{"email": "admin@democorp.com"}	2025-12-06 04:45:37.90923
5	1	2	User Login	{"email": "admin@democorp.com"}	2025-12-06 04:50:19.068695
6	1	2	User Login	{"email": "admin@democorp.com"}	2025-12-06 05:00:36.738945
7	1	2	User Login	{"email": "admin@democorp.com"}	2025-12-06 05:08:33.318691
8	1	2	User Login	{"email": "admin@democorp.com"}	2025-12-06 05:34:01.984649
9	1	2	User Login	{"email": "admin@democorp.com"}	2025-12-06 10:53:58.24724
10	1	2	User Login	{"email": "admin@democorp.com"}	2025-12-06 10:54:53.873903
11	1	2	User Login	{"email": "admin@democorp.com"}	2025-12-06 11:08:41.657313
12	1	2	User Login	{"email": "admin@democorp.com"}	2025-12-06 11:11:22.254086
\.


--
-- Data for Name: case_instances; Type: TABLE DATA; Schema: public; Owner: docent_user
--

COPY public.case_instances (id, template_id, company_id, data_json, generated_summary, created_by, created_at) FROM stdin;
1	1	1	{"title": "Title one", "sections": {"Overview": "Overbiew", "Timeline": "Timeline", "Action Items": "Action items", "Lessons Learned": "Leesson Learned", "Impact Assessment": "Impacr", "Root Cause Analysis": "Root Cause"}, "linked_documents": [19, 15, 14]}	**Case Study Summary**\n\nTitle: Title one\n\nOverview:\nOverbiew\n\nTimeline:\nTimeline\n\nAction Items:\nAction items\n\nLessons Learned:\nLeesson Learned\n\nImpact Assessment:\nImpacr\n\nRoot Cause Analysis:\nRoot Cause\n\n**Sections covered:** Overview, Timeline, Action Items, Lessons Learned, Impact Assessment, Root Cause Analysis	2	2025-12-06 03:43:50.374045
\.


--
-- Data for Name: case_templates; Type: TABLE DATA; Schema: public; Owner: docent_user
--

COPY public.case_templates (id, company_id, name, template_json, created_by, is_default, created_at) FROM stdin;
1	\N	Post-Mortem Analysis	{"sections": ["Overview", "Timeline", "Root Cause Analysis", "Impact Assessment", "Lessons Learned", "Action Items"]}	\N	t	2025-11-23 08:53:39.277536
2	\N	Client Project Summary	{"sections": ["Client Information", "Project Objectives", "Deliverables", "Timeline", "Outcomes", "Next Steps"]}	\N	t	2025-11-23 08:53:39.277536
3	\N	Product Launch Review	{"sections": ["Product Overview", "Launch Strategy", "Key Metrics", "Customer Feedback", "Lessons", "Future Improvements"]}	\N	t	2025-11-23 08:53:39.277536
\.


--
-- Data for Name: companies; Type: TABLE DATA; Schema: public; Owner: docent_user
--

COPY public.companies (id, name, domain_restriction, plan_limits, is_active, created_at) FROM stdin;
1	Demo Corp	\N	{"max_users": 200, "max_storage_gb": 100}	t	2025-11-23 08:53:39.265655
\.


--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: docent_user
--

COPY public.departments (id, company_id, name, parent_id, created_at) FROM stdin;
\.


--
-- Data for Name: doc_chunks; Type: TABLE DATA; Schema: public; Owner: docent_user
--

COPY public.doc_chunks (id, document_id, company_id, chunk_text, chunk_index, chunk_id_for_vector, chunk_metadata, created_at) FROM stdin;
4	14	1	The rise in remote work since the pandemic and its impact on productivity\nBy Sabrina Wulff Pabilonia and Jill Janocha Redmond\n\nImage\nRelated Articles\nRemote Work, Wages, and Hours Worked in the United States\n\nTelework during the COVID-19 pandemic: estimates using the 2021 Business Response Survey\n\nBringing work home: implications for BLS productivity measures\n\nThe COVID-19 pandemic brought about dramatic changes in the work environment. Although 6.5 percent of workers in the private business sector worked primarily from home in 2019, the pandemic was the start of a massive experiment in full-time remote work for most workers and firms.1 People often ask: are workers more productive or less productive when working from home? The answer likely depends on several factors, including the types of tasks workers perform, the available technology, the home environment, worker motivation, and management practices. A few randomized experiments at individual firms identify small positive effects of hybrid and fully remote work on individual employee productivity using metrics such as the number of emails written, phone/video calls made, and the novelty of work products as reported in manager-assigned performance ratings.2 They also find that remote work led to lower job turnover as job satisfaction rose, which could substantially reduce firms’ hiring costs. On the other hand, a couple of single-firm case studies conducted during the pandemic find that employee productivity declined in the short run.3 These studies examine individual labor productivity and use various proxies to measure it. Looking at a more aggregate level to measure the impact of remote work on economic performance across 43 private sector industries, Fernald et al. (2024) find little relationship between labor productivity and the ability of workers in an industry to work entirely remotely, suggesting remote work neither hindered nor helped raise aggregate productivity growth.4\n\nThis Beyond the Numbers article uses data from the BLS productivity program and the American Community Survey (ACS) to shed light on whether remote work can enhance productivity.5 We examine the pandemic-period relationships between the rise in the percentage of workers primarily working from home and the percent change in total factor productivity (TFP), output, and unit input costs across 61 industries in the private business sector. We find that TFP growth over both the 2019–21 and the 2019–22 periods is positively associated with the rise in the percentage of remote workers across 61 industries in the private business sector, even after accounting for pre-pandemic trends in productivity.\n\nThe rise in remote work across industries during the pandemic\nAccording to the American Community Survey (ACS), remote work increased dramatically across all major industries between 2019 and 2021. Then, with the removal of all social distancing policies in 2022, the percentage of remote workers fell slightly. However, remote work participation was still higher than its 2019 level in all industries except agriculture, forestry, fishing, and hunting, which returned to its 2019 level.\n\nIn the ACS, respondents are asked how they usually got to work in the last week. If they respond that they worked from home, we classify them as a remote worker. We note that remote work may be fully remote or hybrid (a combination of remote work and in-person days, but with the majority of days worked from home). Remote work is also commonly referred to as telework. In this article, we compare data from 2019, the year before the pandemic, with data from 2021, the full year after the pandemic began and before major efforts by firms to encourage their employees to return to the office. We also compare 2019 data with 2022 data to see if the relationship between remote work and productivity changed as businesses and employees further adjusted to the new work arrangements.	0	doc_14_chunk_0_11fe4263	{}	2025-12-06 03:13:17.574216
5	14	1	Chart 1 shows the rise in remote work for 21 major industries ranked from largest to smallest by the percentage of remote workers in 2021. Although there was a larger percentage of remote workers in 2021 compared with 2019 in all major industries, four major industries saw phenomenal increases in remote work (by over 30 percentage points). Professional, scientific, and technical services, information, finance and insurance, and management of companies and enterprises had over 39 percent of their workforce working remotely in 2021 compared with less than 17 percent in 2019. Another 12 industries had between 10 and 25 percent of their workforce working remotely in 2021. The four major industries with the largest percentage of their workers remote in 2021 still had at least over 33 percent of their workforce working remotely in 2022.\n\nChart 1. Percent of remote workers by major industry group, ranked from largest to smallest in 2021\nScatter chart with 3 data series.\nThe chart has 1 X axis displaying categories.\nThe chart has 1 Y axis displaying Percent. Data ranges from 1.9 to 46.5.\nEnd of interactive chart.\nView Chart Data\nLooking at a more detailed industry breakdown (61 industries), chart 2 shows that in four of these industries (computer systems design and related services; data processing, internet publishing, and other information services; publishing industries, except internet (includes software); insurance carriers and related activities), the majority of workers (50.2–62.5 percent) worked from home in 2021. In 2019, only 15–20 percent of workers in these same industries worked remotely. Over 40 percent of workers in another three industries (funds, trusts, and other financial vehicles; securities, commodity contracts, and other financial investments and related activities; miscellaneous professional, scientific, and technical services) worked remotely. Of the 61 detailed industries, 44 had more than 10 percent of their workforce working remotely in 2021. In 2022, the top four detailed industries in 2021 still had over 46 percent of their workforce working remotely.\n\nChart 2. Percent of remote workers by detailed industry group, top 10 industries in 2021\nScatter chart with 3 data series.\nThe chart has 1 X axis displaying categories.\nThe chart has 1 Y axis displaying Percent. Data ranges from 6.4 to 62.5.\nEnd of interactive chart.\nView Chart Data\nProductivity increases as remote work increases across 61 detailed industries\nTotal factor productivity is calculated by dividing output by a combination of all inputs used in production.6 Inputs include workers, machinery and other capital, energy, materials, and services. When workers shift their work location from office buildings to their homes, nonlabor inputs also can be expected to change. For example, employers may downsize their office footprints when remote workers are not using commercial office space.7 Businesses may also have lower utility expenses even if they keep their unoccupied office buildings, either because their leases have not yet expired or they intend to use the buildings in the future. In addition, during the pandemic, there was a substantial rise in new businesses that may have opened using relatively more remote workers than onsite workers given the lower fixed costs associated with this type of work arrangement.8 Existing businesses could also have expanded operations without adding additional office space. Also, if worker turnover declined, businesses might purchase fewer outside recruiting services. Thus, even if workers produce the same output remotely, TFP might still increase if firms use fewer nonlabor inputs.	1	doc_14_chunk_1_55073836	{}	2025-12-06 03:13:17.574219
6	14	1	Chart 3 illustrates how the annual percentage growth in total factor productivity (TFP) is related to changes in the percentage of remote workers across 61 industries in the private business sector from 2019 to 2021. The size of the bubbles represents the industry’s share of total private business sector output in 2019. The fitted line shows the output-weighted average relationship between the two measures: a 1 percentage-point increase in the rise in the percentage of remote workers is associated with a 0.08 percentage-point increase in TFP growth. This association is 0.09 in the 2019–22 period, and relationships in both periods are statistically significant.\n\nChart 3. Relationship between remote work and total factor productivity across 61 industries, 2019–21\nCombination chart with 62 data series.\nThe chart has 1 X axis displaying Percentage point change in remote workers . Data ranges from 0.7 to 44.2.\nThe chart has 1 Y axis displaying Percent change in TFP . Data ranges from -14.08092213 to 10.22735786.\nEnd of interactive chart.\nView Chart Data\nChart 4 compares TFP growth over the prior business-cycle (2007–2019) with TFP growth during the first part of the pandemic (2019–21).\n\nChart 4. Pre- and post-pandemic TFP across 61 industries, 2007–19 versus 2019–21, ranked by percentage point increase in remote work, 2019–2021\nBar chart with 2 data series.\nThe chart has 1 X axis displaying categories.\nThe chart has 1 Y axis displaying Percent change in TFP. Data ranges from -2.7 to 10.\nEnd of interactive chart.\nView Chart Data\nThere is considerable variation in TFP growth between the two periods, even among those industries with a large increase in remote workers. For example, the fourth-ranked industry in terms of the rise in remote work—funds, trusts, and other financial vehicles—grew by 10.0 percent in the pandemic, but declined by 0.2 percent in the 2007–19 period. Thus, only some high-productive industries during the pandemic were also highly productive before the pandemic. Nevertheless, many industries that experienced a large increase in remote work also had higher-than-average TFP growth pre-pandemic. Therefore, to better measure the association of the rise in remote work with productivity, we also estimate the relationship between the increase in the percentage of remote workers and the excess in TFP growth in the pandemic period (2019–21) over the prior-business-cycle TFP growth (2007–19). Using this excess TFP growth measure, we still find a positive and statistically significant association between the rise in remote work and TFP growth, although the magnitude of the association is slightly smaller.9 A 1 percentage-point increase in the percentage-point change in remote workers is associated with a 0.05 percentage-points increase in TFP growth.10\n\nWe find the same association between the rise in remote work and excess TFP growth if we look at the excess TFP growth in the 2019–22 period compared with the prior-business-cycle TFP growth.	2	doc_14_chunk_2_b777cd3e	{}	2025-12-06 03:13:17.57422
7	14	1	We find the same association between the rise in remote work and excess TFP growth if we look at the excess TFP growth in the 2019–22 period compared with the prior-business-cycle TFP growth.\n\nOverall, our results suggest that the rise in remote work and TFP growth are positively correlated. From 2019 to 2021, the (weighted) average percentage-point increase in remote workers across industries was 14.9. This suggests that the rise in remote work was associated with an average 1.2 percentage-points increase in industry-level TFP. However, remote work is only one factor that may affect productivity, which rose by 1.5 percent in the private business sector over the same period. Over the 2019–22 period, the 11.8 average percentage-points increase in remote workers across industries was associated with an average 1.1 percentage-points increase in industry-level TFP, whereas private business sector TFP rose by only 0.4 percent over the period. This suggests that the increase in remote work substantially contributed to productivity growth during the pandemic.\n\nIn the following sections, we examine some of the components of productivity growth to help us better understand what might be driving the 2019–22 industry-level relationship between TFP growth and the change in the percentage of remote workers.\n\nOutput and labor input growth in the top 10 industries experiencing the highest percentage-point increase in remote workers\nChart 5 shows the percent changes in output and labor input (a measure of hours worked adjusted for differences in the age, education, and sex composition of the workforce) for the top 10 industries experiencing the highest percentage-point increase in remote work over the 2019–22 period. We see large increases in output and labor input in the top three industries (computer systems design and related services; publishing industries, except internet [includes software]; and data processing, internet publishing, and other information services), with output rising much faster than labor input. Another four of the top industries (securities, commodity contracts, and other financial investments and related activities; management of companies and enterprises; broadcasting and telecommunications; and miscellaneous professional, scientific, and technical services) also have substantial output growth, but either small, positive labor input growth or a small decline in labor input. The remaining three industries have labor input growing faster than output. Thus, most of the industries that experienced substantial increases in the percentage of remote workers were able to enhance output during this time without a corresponding increase in labor.\n\nChart 5. Output and labor input percent changes in the ten industries with the largest gains in remote work, 2019–22\nBar chart with 2 data series.\nThe chart has 1 X axis displaying categories.\nThe chart has 1 Y axis displaying values. Data ranges from -9.9 to 18.8.\nEnd of interactive chart.\nView Chart Data\nProductivity gains did not lead to increased hourly compensation from 2019–22\nIf remote work increases productivity, some gains may be passed down from employers to workers as compensation. At the detailed industry level using a linear regression model, we examine the relationship between the rise in remote work and real hourly compensation growth, a more comprehensive measure of remuneration than wages that is included in the BLS productivity database. We find no statistically significant relationship between the growth in remote work and the growth in hourly compensation, even when controlling for compositional changes in the workforce, suggesting that pandemic-era productivity gains associated with the rise in remote work were not passed along to workers. However, workers gained in other ways. Most significantly, they avoided long commutes, saving them both time and money.11	3	doc_14_chunk_3_8edb9c8f	{}	2025-12-06 03:13:17.574221
8	14	1	Although we find no statistically significant relationship between the rise in remote work and the growth in hourly compensation, chart 6 shows a small negative relationship between the percentage-point change in remote workers and the growth in unit labor costs (the ratio of real hourly compensation to labor productivity, also known as compensation per unit of output). A 1 percentage-point increase in the percentage-point change in remote workers is associated with a 0.1 percentage-point decrease in unit labor costs growth.\n\nChart 6. Relationships between the percentage point change in remote workers and the growth in different unit input costs across 61 industries, 2019–22\nCombination chart with 2 data series.\nThe chart has 1 X axis displaying categories.\nThe chart has 1 Y axis displaying values. Data ranges from -0.77 to 0.04.\nEnd of interactive chart.\nView Chart Data\nUnit nonlabor costs decreased as remote work increased, 2019–22\nOur findings in chart 6 also demonstrate a consistent pattern: the larger the increase in remote work, the larger the decrease in unit capital, energy, material, and service costs growth across industries.12 The associations are notably stronger than the link with unit labor costs, with values ranging from -0.2 to -0.4.\n\nDigging deeper into the detailed asset class categories, we also examine the relationship between the rise in remote work and the growth in unit office building costs. The increase in remote work allowed many businesses to downsize their office footprints. A 1 percentage-point increase in the percentage-point change in remote workers is associated with a 0.4 percentage-point decrease in unit office building costs growth. This negative relationship is driven primarily by two large industries (broadcasting and telecommunications and miscellaneous professional, scientific, and technical services) with decreases in unit office building costs exceeding 20 percent.\n\nConclusion\nRemote work rose dramatically during the COVID-19 pandemic. Total factor productivity growth over the 2019–22 period is positively associated with the rise in the percentage of remote workers across 61 industries in the private business sector, even after accounting for pre-pandemic trends in productivity. This is because unit costs, especially unit nonlabor costs, grew less in industries where more work was done from home. The productivity gains accrued to businesses, however, did not result in increased compensation to workers. Productivity gains can potentially result in higher wages and benefits for workers, greater investments by businesses to improve their products or services, increased profits, and/or lower prices for consumers.\n\nFor more background, data, charts, and research related to remote work see our productivity and remote work page. To learn more about productivity visit the productivity homepage and explore productivity data on the productivity tables page.\n\nThis Beyond the Numbers article was prepared by Sabrina Wulff Pabilonia and Jill Janocha Redmond, economists in the Office of Productivity and Technology, U.S. Bureau of Labor Statistics. E-mail: productivity@bls.gov; telephone: (202) 691-5606.\n\nIf you are deaf, hard of hearing, or have a speech disability, please dial 7-1-1 to access telecommunications relay services or the information voice phone at: (202) 691-5200. This article is in the public domain and may be reproduced without permission.\n\nCompany Policies and Guidelines\n\nRemote Work Policy\nEmployees may work remotely up to 3 days per week with manager approval. Remote workers must be available during core hours (10am-4pm) and attend all scheduled meetings. A stable internet connection and secure workspace are required.\n\nVacation and Time Off\nFull-time employees receive 20 days of paid vacation per year. Vacation requests must be submitted at least 2 weeks in advance. Unused vacation days can be carried over up to 5 days maximum.	4	doc_14_chunk_4_f055735c	{}	2025-12-06 03:13:17.574222
9	14	1	Vacation and Time Off\nFull-time employees receive 20 days of paid vacation per year. Vacation requests must be submitted at least 2 weeks in advance. Unused vacation days can be carried over up to 5 days maximum.\n\nExpense Reimbursement\nBusiness expenses must be submitted within 30 days with receipts. Approved categories include travel, meals during business trips, and professional development. All expenses over $500 require pre-approval from your manager.\n\nPerformance Reviews\nPerformance reviews are conducted twice per year in June and December. Employees should complete self-assessments one week before their scheduled review meeting. Goals are set collaboratively with managers.\n\nSecurity Guidelines\nAll employees must use two-factor authentication for company systems. Passwords must be changed every 90 days. Report any suspicious emails to security@company.com immediately.	5	doc_14_chunk_5_e57fcd3f	{}	2025-12-06 03:13:17.574223
15	19	1	نریشن: فینیکس – شریک فکر، نه فروشنده\n\nقلاب:\n«آدم‌ها معمولاً از یک مشاور املاک انتظار دارن چیزی پیشنهاد بده؛ اما واقعیت اینه که وقتی پای سرمایه و آینده وسطه، تو دنبال کسی می‌گردی که باهات فکر کنه، نه اینکه فقط چیزی رو بفروشه.»	4	doc_19_chunk_4_925048c7	{}	2025-12-06 03:34:02.893858
10	15	1	Project Management Best Practices\n\nProject Planning Phase\nEvery project begins with a kickoff meeting to align stakeholders. Create a project charter defining scope, timeline, and success metrics. Break down work into sprints of 2 weeks each.\n\nCommunication Standards\nDaily standup meetings should last no more than 15 minutes. Use Slack for quick questions, email for formal communications. Weekly status reports are due every Friday by 5pm.\n\nRisk Management\nIdentify potential risks during the planning phase. Maintain a risk register with mitigation strategies. Escalate blockers to leadership within 24 hours if unresolved.\n\nDocumentation Requirements\nAll projects must have a README file in the repository. Technical decisions should be recorded in Architecture Decision Records. Meeting notes must be shared within 24 hours.\n\nQuality Assurance\nCode reviews are required before merging to main branch. Automated tests must achieve 80% coverage minimum. User acceptance testing is mandatory before production deployment.\n\nBudget Tracking\nProject budgets are reviewed monthly with finance. Variance reports are required for any deviation over 10%. Resource allocation changes need PMO approval.	0	doc_15_chunk_0_1f3ba43f	{}	2025-12-06 03:13:17.969978
11	19	1	نریشن ۱ - زندگی با آرامش در دبی\nنریشن۲ -  فینیکس امپریال  - مسیر اختصاصی\nنریشن۳ : دبی؛ مقصد کسانی که آینده را می‌سازند\nنریشن۴ : فینیکس – شریک فکر، نه فروشنده\nنریشن ۵: «داماک – سازنده‌ای برای زندگی»\n\nنریشن ۱ - زندگی با آرامش در دبی\nقلاب:\n«خیلیا وقتی اسم دبی میاد یاد برج‌ها می‌افتن؛ اما کسایی که اینجا زندگی کردن می‌گن دبی اول از همه یک حسه—یه آرامش که انگار هیچ‌چیز ازت دور نیست و هیچ فرصتی ازت جا نمی‌مونه.»\nبدنه:\nتصور کن صبح با صدای شهر بیدار می‌شی، پنج دقیقه تا ساحل، ده دقیقه تا بهترین مراکز خرید، مدرسه‌ی بچه‌ها هم همون نزدیکی. همه‌چیز سرراست، تمیز، امن.\nو از اون‌طرف، دارایی‌ای که دستت داری به دلار رشد می‌کنه—نه فقط با آرامش زندگی، با رشد واقعی سرمایه. هر پرداختی، هر متری که به نامت می‌شه، بخشی از شهریه که داره آینده رو می‌سازه؛ جایی که قیمت‌هاش نوسان نمی‌کنه، حرکت می‌کنه—رو‌به‌جلو.\nاینجا زندگی و سرمایه‌گذاری از هم جدا نیست؛ هر روزی که اینجا هستی، هم حس بهتری داری، هم ارزش بیشتری.	0	doc_19_chunk_0_8bbb94e6	{}	2025-12-06 03:34:02.893851
12	19	1	CTA:\nاگه می‌خوای بدونی این سبک زندگی برای تو چطور معنا پیدا می‌کنه—آپارتمان شهری، ساحلی یا حتی یک ویلای خلوت—یه پیام با کلمه‌ی DUBAI بفرست. با هم می‌بینیم چطور می‌تونی همین امروز قدم اولت رو بزنی… آرام، منطقی و به دلار.\n \n \nنریشن۲ -  فینیکس امپریال\nقلاب:\n«آدم‌ها معمولاً دنبال یک مشاور املاک می‌گردن؛ اما وقتی پای ۲۰ سال تجربه در دبی وسط باشه، موضوع فقط خرید یا فروش نیست موضوع اینه که چه کسی کنارته؟»\nبدنه:\nما از ۲۰ سال حضور مداوم در دبی شروع کردیم؛ سال‌هایی که به بیش از ۳۸۰۰ سرمایه‌گذار ایرانی و بین‌المللی کمک کردیم مسیر خودشون رو پیدا کنن از انتخاب ملک، تا رشد سرمایه، تا شروع یک زندگی آرام برای خودشون و فرزندانشون.	1	doc_19_chunk_1_d1987721	{}	2025-12-06 03:34:02.893854
13	19	1	ما فقط ملک معرفی نکردیم؛ به راه‌اندازی کسب‌وکارها کمک کردیم، مسیر مهاجرت و سبک زندگی رو شفاف کردیم، و کنار مشتری‌هایی بودیم که به‌خاطر اعتمادشون، سرمایه‌شون رو در یکی از امن‌ترین بازارهای دنیا چند برابر کردند.\nسال‌های همکاری با اعمار، داماک، شوبا، حبتور و بقیه‌ی سازنده‌های بزرگ توی امارات به ما یه چیز یاد داد: تجربهٔ واقعی یعنی اینکه بدونی برای هر آدم، یک مسیر «اختصاصی» وجود داره، مسیر سرمایه، مسیر زندگی، و مسیر آینده.\nفینیکس امپریال برای همین به‌وجود آمده؛ برای اینکه انتخاب‌هات فقط یک خرید نباشد، برای اینکه اونها تبدیل بشن به یک طرح زندگی طراحی‌شده برای آرامش، رشد، و امنیت سرمایه‌ی تو.\nCTA:\nاگر می‌خواهی بدونی مسیر مناسب تو چیه؟  یک پیام با کلمهٔ PHOENIX بفرست.\nبیایید با هم مسیر اختصاصی تو رو طراحی کنیم. مسیر تو… نه یک نسخهٔ عمومی.\n \nنریشن۳ : دبی؛ مقصد کسانی که آینده را می‌سازند	2	doc_19_chunk_2_b4171be2	{}	2025-12-06 03:34:02.893857
14	19	1	قلاب:\nخیلی‌ها دنبال جایی می‌گردن که فقط امروز رو بهتر کنه؛ اما اونهایی که آینده رو می‌سازن یک چیز رو خوب می‌دونن: مقصد باید جایی باشه که فرصت‌ها هر روز واقعی‌تر بشن. برای خیلی‌ها، اونجا دبیه.\nبدنه:\nدبی فقط یک شهر مدرن یا یک منظره پرنور نیست؛ جاییه که آدم‌ها با هدف می‌آن. کسی که وارد این شهر می‌شه دنبال شانس نیست، دنبال مسیر ساختن آینده‌ست؛ آینده‌ای که روی ثبات دلار بنا شده، روی امنیت سرمایه، روی بازاری که رو به جلو حرکت می‌کنه نه بالا و پایین.\nزندگی اینجا یعنی آرامش از اینکه همه‌چیز دمِ دسته؛ از مدرسه و کار گرفته تا ساحل و تفریح. یعنی بدانی تصمیمی که امروز می‌گیری، چند سال بعد برای تو و خانواده‌ات تبدیل به یک نقطه برگشت مهم می‌شه.\nدبی مقصد کسانیه که می‌خوان کیفیت زندگی و رشد سرمایه هم‌زمان اتفاق بیفته؛ نه یکی به قیمت دیگری. جایی که هر قدمی که برمی‌داری، یک قدم به جلوست؛ چه در زندگی روزمره، چه در ارزش دارایی‌ات.\n\nCTA:\nاگر می‌خواهی ببینی دبی برای هدف‌ها و آینده تو چه تصویر متفاوتی می‌سازه، یک پیام با کلمه DUBAI بفرست.\nبا هم بررسی می‌کنیم چه مسیری برای آینده تو درست‌تره؛ مسیری که نه رویا، بلکه انتخاب آگاهانه‌ست.	3	doc_19_chunk_3_07025c83	{}	2025-12-06 03:34:02.893857
16	19	1	بدنه:\nفینیکس از روز اول با همین نگاه شکل گرفت؛ اینکه تصمیم‌های مالی و زندگی مردم، فقط به امروز مربوط نیستند، به سال‌ها بعد مربوط‌اند.\nما کنار هزاران خانواده، سرمایه‌گذار و مهاجر ایستادیم؛ نه با عجله، نه با فشار، بلکه با فهمیدن اینکه هر نفر یک نگاه متفاوت به آینده داره. به‌جای این‌که مشتری رو هل بدیم سمت یک پروژه، نشستیم و سناریو ساختیم؛ سناریوی سرمایه‌ای، سناریوی زندگی، سناریوی ماندگاری. این‌که بدونه کجا آرامش پیدا می‌کنه، کجا سرمایه‌اش رشد می‌کنه، و کجا تصمیمش تبدیل می‌شه به یک مسیر جدید. سال‌ها همکاری با برترین سازنده‌های امارات فقط یک چیز رو ثابت کرد: وقتی کنار کسی فکر می‌کنی، انتخابش مطمئن‌تره، مسیرش هموارتره، و نتیجه‌اش پایدارتر.\nفینیکس امپریال فقط یک فروشنده نیست؛ یک شریک فکریه برای طراحی راهی که هم به امروزت می‌خوره، هم آینده‌ت رو می‌سازه.\nCTA:\nاگر می‌خوای بدونی مسیر درست تو از کجا شروع می‌شه، یک پیام با کلمه PHOENIX بفرست.\nبنشینیم، با هم فکر کنیم، و بهترین مسیر رو برای آینده تو طراحی کنیم.	5	doc_19_chunk_5_67dfc06f	{}	2025-12-06 03:34:02.893859
17	19	1	نریشن: «داماک – سازنده‌ای برای زندگی»\nقلاب:\n«خیلی‌ها داماک رو فقط با برج‌های بلند و لانچ‌های پر سر‌وصدا می‌شناسند؛ اما واقعیت اینه که داماک یک چیز رو بهتر از هر کسی بلد است: ساختن سبک زندگی… نه فقط ساختمان.»\nبدنه:\nداماک از اوایل دهه دو هزار میلادی شروع کرد؛ و امروز، بعضی از شناخته‌شده‌ترین جوامع دبی را ساخته.\nپروژه‌هایی مثل DAMAC Hills؛ جایی که زندگی شهری با زمین گلف، پارک‌های بزرگ و مدرسه و فروشگاه در یک جامعه کامل ترکیب شده.\nیا DAMAC Lagoons که زندگی در ویلا و تاون‌هاوس رو با ساحل و لاگون‌های آبی کنار هم آورد و یکی از پرفروش‌ترین پروژه‌های دبی شد.\nدر Aykon City، دسترسی مستقیم به شیخ‌زاید رو تبدیل کرد به یک مزیت واقعی برای سرمایه‌گذارا؛\nو توی پروژه‌های جدیدترش مثل Coral Reef، هنر، تکنولوژی و طراحی مدرن رو در یک برج ساحلی کنار هم گذاشت.\nداستان داماک همیشه یک چیز بوده: خلق پروژه‌هایی که فقط برای سکونت ساخته نمی‌شن، بلکه برای تجربه کردن زندگی. از انتخاب لوکیشن‌ها، تا امضای طراحی، تا جامعه‌هایی که کم‌کم تبدیل می‌شن به مقصد‌های اصلی خانواده‌ها و سرمایه‌گذاران. به خاطر همین هست که داماک فقط یک سازنده معروف نیست؛ یک برند است. یک شخصیت	6	doc_19_chunk_6_feb5e705	{}	2025-12-06 03:34:02.893859
18	19	1	برندی که می‌دونه خونه فقط یک واحد نیست؛ بخشی از آینده‌ی آدم‌هاست.	7	doc_19_chunk_7_84026b0d	{}	2025-12-06 03:34:02.89386
19	19	1	CTA:\nاگر می‌خوای بدونی کدوم پروژه داماک با بودجه، هدف و سبک زندگی تو همخونی داره، یک پیام با کلمه DAMAC بفرست.\nما کمکت می‌کنیم از بین این همه گزینه، دقیقا همان جامعه‌ای را انتخاب کنی که به درد زندگی تو می‌خورد؛ نه فقط سرمایه‌گذاری.\n\nنریشن های بعدی:\n\nنریشن: دبی؛ شهری برای کسانی که می‌خواهند پیش بیفتند، نه عقب نمانند\nنریشن: آینده فرزندان در دبی\nنریشن: انتخاب هوشمندانه در بازار دبی\nنریشن: تجربه ساختن یک آینده دلاری\nنریشن: دبی، شهری که فرصت می‌سازد\nنریشن: مسیر مهاجرت و سرمایه‌گذاری میتونه یکی باشه	8	doc_19_chunk_8_b692047c	{}	2025-12-06 03:34:02.89386
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: docent_user
--

COPY public.documents (id, company_id, uploaded_by, filename, mime_type, storage_path, status, doc_metadata, summary, created_at, processed_at) FROM stdin;
14	1	2	company_policies.txt	text/plain	company_1/20251206_031214_e42a8f9f.txt	processed	{}	The rise in remote work since the pandemic and its impact on productivity\nBy Sabrina Wulff Pabilonia and Jill Janocha Redmond\n\nImage\nRelated Articles\nRemote Work, Wages, and Hours Worked in the United States\n\nTelework during the COVID-19 pandemic: estimates using the 2021 Business Response Survey\n\nBringing work home: implications for BLS productivity measures\n\nThe COVID-19 pandemic brought about dramatic changes in the work environment. Although 6.5 percent of workers in the private business sec...	2025-12-06 03:12:14.028001	2025-12-06 03:13:17.571
15	1	2	project_management.txt	text/plain	company_1/20251206_031214_a9eacd7a.txt	processed	{}	Project Management Best Practices\n\nProject Planning Phase\nEvery project begins with a kickoff meeting to align stakeholders. Create a project charter defining scope, timeline, and success metrics. Break down work into sprints of 2 weeks each.\n\nCommunication Standards\nDaily standup meetings should last no more than 15 minutes. Use Slack for quick questions, email for formal communications. Weekly status reports are due every Friday by 5pm.\n\nRisk Management\nIdentify potential risks during the plan...	2025-12-06 03:12:14.035761	2025-12-06 03:13:17.968185
19	1	2	KAMAKAMA.txt	text/plain	company_1/20251206_032521_7cd459aa.txt	processed	{}	نریشن ۱ - زندگی با آرامش در دبی\nنریشن۲ -  فینیکس امپریال  - مسیر اختصاصی\nنریشن۳ : دبی؛ مقصد کسانی که آینده را می‌سازند\nنریشن۴ : فینیکس – شریک فکر، نه فروشنده\nنریشن ۵: «داماک – سازنده‌ای برای زندگی»\n\n\n\n\n\n\n \n\nنریشن ۱ - زندگی با آرامش در دبی\nقلاب:\n«خیلیا وقتی اسم دبی میاد یاد برج‌ها می‌افتن؛ اما کسایی که اینجا زندگی کردن می‌گن دبی اول از همه یک حسه—یه آرامش که انگار هیچ‌چیز ازت دور نیست و هیچ فرصتی ازت جا نمی‌مونه.»\nبدنه:\nتصور کن صبح با صدای شهر بیدار می‌شی، پنج دقیقه تا ساحل، ده دقیقه تا بهترین مر...	2025-12-06 03:25:21.61679	2025-12-06 03:34:02.890182
\.


--
-- Data for Name: onboarding_paths; Type: TABLE DATA; Schema: public; Owner: docent_user
--

COPY public.onboarding_paths (id, company_id, department_id, name, steps_json, created_by, created_at) FROM stdin;
1	1	\N	New Employee Onboarding	{"steps": [{"order": 1, "title": "Welcome & Introduction", "content": null, "description": "Meet your team and learn about the company", "document_ids": []}, {"order": 2, "title": "HR Paperwork", "content": null, "description": "Complete all required HR documents", "document_ids": []}, {"order": 3, "title": "IT Setup", "content": null, "description": "Get your accounts and equipment set up", "document_ids": []}, {"order": 4, "title": "Training Videos", "content": null, "description": "Watch required training materials", "document_ids": []}, {"order": 5, "title": "First Project", "content": null, "description": "Start working on your first assignment", "document_ids": []}], "total_steps": 5}	2	2025-12-05 11:59:27.413201
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: docent_user
--

COPY public.roles (id, company_id, name, permissions, created_at) FROM stdin;
1	1	Admin	{"can_manage_docs": true, "can_manage_users": true, "can_view_analytics": true}	2025-11-23 08:53:39.268978
2	1	Department Lead	{"can_manage_docs": true, "can_create_templates": true}	2025-11-23 08:53:39.268978
3	1	Employee	{"can_search": true, "can_view_docs": true}	2025-11-23 08:53:39.268978
\.


--
-- Data for Name: search_history; Type: TABLE DATA; Schema: public; Owner: docent_user
--

COPY public.search_history (id, user_id, company_id, query_text, results_meta, "timestamp") FROM stdin;
1	2	1	test search	{"top_score": 0, "total_results": 0, "search_time_ms": 537.88}	2025-12-05 10:27:11.960443
2	2	1	test search	{"top_score": 0, "total_results": 0, "search_time_ms": 347.59}	2025-12-05 10:27:22.792436
3	2	1	onboarding process	{"top_score": 0.6569, "total_results": 2, "search_time_ms": 554.12}	2025-12-05 10:38:45.081037
4	2	1	remote work policy	{"top_score": 0.6705, "total_results": 2, "search_time_ms": 434.92}	2025-12-05 10:38:45.56309
5	2	1	project management	{"top_score": 0.5975, "total_results": 1, "search_time_ms": 782.2}	2025-12-05 11:21:15.257093
6	2	1	remote work	{"filters": {}, "top_score": 0.622, "total_results": 1, "search_time_ms": 726.45}	2025-12-05 11:29:22.640908
7	2	1	REMOTE WORK	{"filters": {}, "top_score": 0.5977, "total_results": 1, "search_time_ms": 546.02}	2025-12-05 11:34:04.106298
8	2	1	project management	{"filters": {}, "top_score": 0.5975, "total_results": 1, "search_time_ms": 553.0}	2025-12-05 12:02:42.432154
9	2	1	remote	{"filters": {}, "top_score": 0.5847, "total_results": 1, "search_time_ms": 883.91}	2025-12-05 17:00:21.903852
10	2	1	team	{"filters": {}, "top_score": 0, "total_results": 0, "search_time_ms": 610.37}	2025-12-05 18:39:27.470206
11	2	1	kind	{"filters": {}, "top_score": 0, "total_results": 0, "search_time_ms": 439.28}	2025-12-05 18:39:33.937867
12	2	1	remote	{"filters": {}, "top_score": 0, "total_results": 0, "search_time_ms": 432.26}	2025-12-05 18:39:37.991281
13	2	1	remote work	{"filters": {}, "top_score": 0, "total_results": 0, "search_time_ms": 672.4}	2025-12-05 18:39:40.770094
14	2	1	project management	{"filters": {}, "top_score": 0, "total_results": 0, "search_time_ms": 376.82}	2025-12-05 18:39:42.958837
15	2	1	REMOTE WORK	{"filters": {}, "top_score": 0, "total_results": 0, "search_time_ms": 438.66}	2025-12-05 18:39:44.497532
16	2	1	project management	{"filters": {}, "top_score": 0, "total_results": 0, "search_time_ms": 507.8}	2025-12-05 18:39:45.671021
17	2	1	remote	{"filters": {}, "top_score": 0, "total_results": 0, "search_time_ms": 372.53}	2025-12-05 18:39:46.785452
18	2	1	REMOTE WORK	{"filters": {}, "top_score": 0, "total_results": 0, "search_time_ms": 391.08}	2025-12-05 18:39:52.039185
19	2	1	project management	{"filters": {}, "top_score": 0, "total_results": 0, "search_time_ms": 388.82}	2025-12-05 18:39:56.93301
20	2	1	REMOTE WORK	{"filters": {}, "top_score": 0, "total_results": 0, "search_time_ms": 555.82}	2025-12-05 18:43:08.718613
21	2	1	remote	{"filters": {}, "top_score": 0, "total_results": 0, "search_time_ms": 631.54}	2025-12-06 03:00:54.038294
22	2	1	project management	{"filters": {}, "top_score": 0, "total_results": 0, "search_time_ms": 444.1}	2025-12-06 03:00:56.697498
23	2	1	remote	{"filters": {}, "top_score": 0, "total_results": 0, "search_time_ms": 518.02}	2025-12-06 03:00:58.045863
24	2	1	REMOTE WORK	{"filters": {}, "top_score": 0, "total_results": 0, "search_time_ms": 387.69}	2025-12-06 03:00:59.130942
25	2	1	project management	{"filters": {}, "top_score": 0, "total_results": 0, "search_time_ms": 381.55}	2025-12-06 03:01:00.50951
26	2	1	REMOTE WORK	{"filters": {}, "top_score": 0, "total_results": 0, "search_time_ms": 390.86}	2025-12-06 03:01:01.571003
27	2	1	REMOTE WORK	{"filters": {}, "top_score": 0, "total_results": 0, "search_time_ms": 399.51}	2025-12-06 03:01:58.551983
28	2	1	remote	{"filters": {}, "top_score": 0, "total_results": 0, "search_time_ms": 340.65}	2025-12-06 03:02:05.577276
29	2	1	REMOTE WORK	{"filters": {}, "top_score": 0, "total_results": 0, "search_time_ms": 333.38}	2025-12-06 03:02:07.825749
30	2	1	i	{"filters": {}, "top_score": 0, "total_results": 0, "search_time_ms": 375.29}	2025-12-06 03:02:11.568633
31	2	1	remote work	{"filters": {}, "top_score": 0, "total_results": 0, "search_time_ms": 406.05}	2025-12-06 03:02:46.754491
32	2	1	remote	{"filters": {}, "top_score": 0, "total_results": 0, "search_time_ms": 461.08}	2025-12-06 03:02:57.055517
33	2	1	remote	{"filters": {}, "top_score": 0, "total_results": 0, "search_time_ms": 392.8}	2025-12-06 03:02:57.65202
34	2	1	remote	{"filters": {}, "top_score": 0, "total_results": 0, "search_time_ms": 314.37}	2025-12-06 03:02:59.407189
35	2	1	benefit	{"filters": {}, "top_score": 0, "total_results": 0, "search_time_ms": 449.25}	2025-12-06 03:03:05.764457
36	2	1	remote	{"filters": {}, "top_score": 0, "total_results": 0, "search_time_ms": 419.05}	2025-12-06 03:05:24.686733
37	2	1	remote	{"filters": {}, "top_score": 0, "total_results": 0, "search_time_ms": 352.56}	2025-12-06 03:05:31.983645
38	2	1	remote	{"filters": {}, "top_score": 0.6295, "total_results": 5, "search_time_ms": 438.26}	2025-12-06 03:13:44.054236
39	2	1	remote	{"filters": {}, "top_score": 0.6295, "total_results": 5, "search_time_ms": 530.49}	2025-12-06 03:39:41.848651
40	2	1	case	{"filters": {}, "top_score": 0.6082, "total_results": 5, "search_time_ms": 656.18}	2025-12-06 04:06:36.766428
41	2	1	خانواده	{"filters": {}, "top_score": 0.6795, "total_results": 5, "search_time_ms": 398.6}	2025-12-06 04:06:47.470038
42	2	1	remote	{"filters": {}, "top_score": 0.6295, "total_results": 5, "search_time_ms": 568.1}	2025-12-06 04:50:35.054995
43	2	1	remote	{"filters": {}, "top_score": 0.6295, "total_results": 5, "search_time_ms": 785.95}	2025-12-06 05:08:49.779628
44	2	1	case	{"filters": {}, "top_score": 0.6082, "total_results": 5, "search_time_ms": 682.54}	2025-12-06 05:15:29.060029
45	2	1	case	{"filters": {}, "top_score": 0.6082, "total_results": 5, "search_time_ms": 426.74}	2025-12-06 05:15:31.182234
46	2	1	case	{"filters": {}, "top_score": 0.6082, "total_results": 5, "search_time_ms": 404.22}	2025-12-06 05:15:32.579678
47	2	1	remote	{"filters": {}, "top_score": 0.6295, "total_results": 5, "search_time_ms": 312.05}	2025-12-06 05:15:34.292289
48	2	1	remote	{"filters": {}, "top_score": 0.6295, "total_results": 5, "search_time_ms": 370.27}	2025-12-06 05:15:35.72017
\.


--
-- Data for Name: system_admins; Type: TABLE DATA; Schema: public; Owner: docent_user
--

COPY public.system_admins (id, email, hashed_password, name, is_active, created_at) FROM stdin;
2	hamed.niavand@gmail.com	240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9	Hamed Niavand	t	2025-11-23 08:53:39.262274
\.


--
-- Data for Name: user_onboarding_progress; Type: TABLE DATA; Schema: public; Owner: docent_user
--

COPY public.user_onboarding_progress (id, user_id, path_id, company_id, current_step, completed_steps, progress_data, started_at, completed_at) FROM stdin;
1	2	1	1	5	[0, 1, 2, 3, 4]	{}	2025-12-05 17:01:03.926677	2025-12-06 02:59:46.913991
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: docent_user
--

COPY public.users (id, company_id, role_id, email, hashed_password, name, is_active, last_login, created_at, notification_preferences) FROM stdin;
3	1	3	employee@democorp.com	ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f	John Employee Updated	t	\N	2025-11-23 10:40:28.743685	{"email_on_new_case": true, "email_weekly_digest": true, "email_onboarding_reminders": true, "email_on_document_processed": true}
6	1	3	HAMNIAWEBSITE@gmail.com	\N	Test NameS	t	\N	2025-11-23 13:01:55.363873	{"email_on_new_case": true, "email_weekly_digest": true, "email_onboarding_reminders": true, "email_on_document_processed": true}
7	1	3	test.day7@democorp.com	ecd71870d1963316a97e3ac3408c9835ad8cf0f3c1bc703527c30265534f75ae	Day 7 Test User	t	\N	2025-11-24 06:53:34.771564	{"email_on_new_case": true, "email_weekly_digest": true, "email_onboarding_reminders": true, "email_on_document_processed": true}
1	1	3	john.doe@democorp.com	ef92b778bafe771e89245b89ecbc08a44a4e166c06659911881f383d4473e94f	John Doe	t	\N	2025-11-23 10:35:33.102901	{"email_on_new_case": true, "email_weekly_digest": true, "email_onboarding_reminders": true, "email_on_document_processed": true}
4	1	3	hamed.niavand@gmail.com	\N	Test Name	f	\N	2025-11-23 13:00:40.564304	{"email_on_new_case": true, "email_weekly_digest": true, "email_onboarding_reminders": true, "email_on_document_processed": true}
5	1	3	hamedniavand@gmail.com	\N	Test Name	f	\N	2025-11-23 13:00:53.501727	{"email_on_new_case": true, "email_weekly_digest": true, "email_onboarding_reminders": true, "email_on_document_processed": true}
2	1	1	admin@democorp.com	240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9	Demo Corp Admin	t	2025-12-06 11:11:22.251946	2025-11-23 10:40:28.524913	{"email_on_new_case": false, "email_weekly_digest": false, "email_onboarding_reminders": false, "email_on_document_processed": false}
\.


--
-- Name: activity_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: docent_user
--

SELECT pg_catalog.setval('public.activity_logs_id_seq', 12, true);


--
-- Name: case_instances_id_seq; Type: SEQUENCE SET; Schema: public; Owner: docent_user
--

SELECT pg_catalog.setval('public.case_instances_id_seq', 1, true);


--
-- Name: case_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: docent_user
--

SELECT pg_catalog.setval('public.case_templates_id_seq', 3, true);


--
-- Name: companies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: docent_user
--

SELECT pg_catalog.setval('public.companies_id_seq', 1, true);


--
-- Name: departments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: docent_user
--

SELECT pg_catalog.setval('public.departments_id_seq', 1, false);


--
-- Name: doc_chunks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: docent_user
--

SELECT pg_catalog.setval('public.doc_chunks_id_seq', 19, true);


--
-- Name: documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: docent_user
--

SELECT pg_catalog.setval('public.documents_id_seq', 19, true);


--
-- Name: onboarding_paths_id_seq; Type: SEQUENCE SET; Schema: public; Owner: docent_user
--

SELECT pg_catalog.setval('public.onboarding_paths_id_seq', 2, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: docent_user
--

SELECT pg_catalog.setval('public.roles_id_seq', 3, true);


--
-- Name: search_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: docent_user
--

SELECT pg_catalog.setval('public.search_history_id_seq', 48, true);


--
-- Name: system_admins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: docent_user
--

SELECT pg_catalog.setval('public.system_admins_id_seq', 2, true);


--
-- Name: user_onboarding_progress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: docent_user
--

SELECT pg_catalog.setval('public.user_onboarding_progress_id_seq', 2, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: docent_user
--

SELECT pg_catalog.setval('public.users_id_seq', 7, true);


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_pkey PRIMARY KEY (id);


--
-- Name: case_instances case_instances_pkey; Type: CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.case_instances
    ADD CONSTRAINT case_instances_pkey PRIMARY KEY (id);


--
-- Name: case_templates case_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.case_templates
    ADD CONSTRAINT case_templates_pkey PRIMARY KEY (id);


--
-- Name: companies companies_pkey; Type: CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.companies
    ADD CONSTRAINT companies_pkey PRIMARY KEY (id);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: doc_chunks doc_chunks_chunk_id_for_vector_key; Type: CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.doc_chunks
    ADD CONSTRAINT doc_chunks_chunk_id_for_vector_key UNIQUE (chunk_id_for_vector);


--
-- Name: doc_chunks doc_chunks_pkey; Type: CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.doc_chunks
    ADD CONSTRAINT doc_chunks_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: onboarding_paths onboarding_paths_pkey; Type: CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.onboarding_paths
    ADD CONSTRAINT onboarding_paths_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: search_history search_history_pkey; Type: CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.search_history
    ADD CONSTRAINT search_history_pkey PRIMARY KEY (id);


--
-- Name: system_admins system_admins_email_key; Type: CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.system_admins
    ADD CONSTRAINT system_admins_email_key UNIQUE (email);


--
-- Name: system_admins system_admins_pkey; Type: CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.system_admins
    ADD CONSTRAINT system_admins_pkey PRIMARY KEY (id);


--
-- Name: user_onboarding_progress user_onboarding_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.user_onboarding_progress
    ADD CONSTRAINT user_onboarding_progress_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_activity_logs_company; Type: INDEX; Schema: public; Owner: docent_user
--

CREATE INDEX idx_activity_logs_company ON public.activity_logs USING btree (company_id);


--
-- Name: idx_activity_logs_timestamp; Type: INDEX; Schema: public; Owner: docent_user
--

CREATE INDEX idx_activity_logs_timestamp ON public.activity_logs USING btree ("timestamp");


--
-- Name: idx_doc_chunks_company; Type: INDEX; Schema: public; Owner: docent_user
--

CREATE INDEX idx_doc_chunks_company ON public.doc_chunks USING btree (company_id);


--
-- Name: idx_doc_chunks_document; Type: INDEX; Schema: public; Owner: docent_user
--

CREATE INDEX idx_doc_chunks_document ON public.doc_chunks USING btree (document_id);


--
-- Name: idx_doc_chunks_vector_id; Type: INDEX; Schema: public; Owner: docent_user
--

CREATE INDEX idx_doc_chunks_vector_id ON public.doc_chunks USING btree (chunk_id_for_vector);


--
-- Name: idx_documents_company; Type: INDEX; Schema: public; Owner: docent_user
--

CREATE INDEX idx_documents_company ON public.documents USING btree (company_id);


--
-- Name: idx_documents_status; Type: INDEX; Schema: public; Owner: docent_user
--

CREATE INDEX idx_documents_status ON public.documents USING btree (status);


--
-- Name: idx_search_history_company; Type: INDEX; Schema: public; Owner: docent_user
--

CREATE INDEX idx_search_history_company ON public.search_history USING btree (company_id);


--
-- Name: idx_search_history_user; Type: INDEX; Schema: public; Owner: docent_user
--

CREATE INDEX idx_search_history_user ON public.search_history USING btree (user_id);


--
-- Name: idx_user_onboarding_company; Type: INDEX; Schema: public; Owner: docent_user
--

CREATE INDEX idx_user_onboarding_company ON public.user_onboarding_progress USING btree (company_id);


--
-- Name: idx_user_onboarding_path; Type: INDEX; Schema: public; Owner: docent_user
--

CREATE INDEX idx_user_onboarding_path ON public.user_onboarding_progress USING btree (path_id);


--
-- Name: idx_user_onboarding_user; Type: INDEX; Schema: public; Owner: docent_user
--

CREATE INDEX idx_user_onboarding_user ON public.user_onboarding_progress USING btree (user_id);


--
-- Name: idx_users_company; Type: INDEX; Schema: public; Owner: docent_user
--

CREATE INDEX idx_users_company ON public.users USING btree (company_id);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: docent_user
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: activity_logs activity_logs_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: activity_logs activity_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: case_instances case_instances_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.case_instances
    ADD CONSTRAINT case_instances_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: case_instances case_instances_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.case_instances
    ADD CONSTRAINT case_instances_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: case_instances case_instances_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.case_instances
    ADD CONSTRAINT case_instances_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.case_templates(id) ON DELETE CASCADE;


--
-- Name: case_templates case_templates_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.case_templates
    ADD CONSTRAINT case_templates_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: case_templates case_templates_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.case_templates
    ADD CONSTRAINT case_templates_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: departments departments_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: departments departments_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.departments(id) ON DELETE SET NULL;


--
-- Name: doc_chunks doc_chunks_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.doc_chunks
    ADD CONSTRAINT doc_chunks_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: doc_chunks doc_chunks_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.doc_chunks
    ADD CONSTRAINT doc_chunks_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: documents documents_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: documents documents_uploaded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_uploaded_by_fkey FOREIGN KEY (uploaded_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: onboarding_paths onboarding_paths_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.onboarding_paths
    ADD CONSTRAINT onboarding_paths_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: onboarding_paths onboarding_paths_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.onboarding_paths
    ADD CONSTRAINT onboarding_paths_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: onboarding_paths onboarding_paths_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.onboarding_paths
    ADD CONSTRAINT onboarding_paths_department_id_fkey FOREIGN KEY (department_id) REFERENCES public.departments(id) ON DELETE SET NULL;


--
-- Name: roles roles_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: search_history search_history_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.search_history
    ADD CONSTRAINT search_history_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: search_history search_history_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.search_history
    ADD CONSTRAINT search_history_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_onboarding_progress user_onboarding_progress_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.user_onboarding_progress
    ADD CONSTRAINT user_onboarding_progress_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: user_onboarding_progress user_onboarding_progress_path_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.user_onboarding_progress
    ADD CONSTRAINT user_onboarding_progress_path_id_fkey FOREIGN KEY (path_id) REFERENCES public.onboarding_paths(id) ON DELETE CASCADE;


--
-- Name: user_onboarding_progress user_onboarding_progress_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.user_onboarding_progress
    ADD CONSTRAINT user_onboarding_progress_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_company_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_company_id_fkey FOREIGN KEY (company_id) REFERENCES public.companies(id) ON DELETE CASCADE;


--
-- Name: users users_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: docent_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict s04IgkFwENZs3U7rb1smnOaXJ2T5I9rcbQWOnjP0mGAUiAfsUgnvZgQxjHfwtrb

